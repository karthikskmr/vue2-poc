<template>
    <div>
        <div style="margin-bottom: 20px;">
            this is landing page
        </div>

        <div class="container">
            <b-card title="Card Title" img-src="https://picsum.photos/600/300/?image=25" img-alt="Image" img-top
                tag="article" style="max-width: 20rem;" class="mb-2">
                <b-card-text>
                    Some quick example text to build on the card title and make up the bulk of the card's content. {{ name
                    }}
                </b-card-text>

                <b-button href="#" variant="primary">Go somewhere</b-button>
            </b-card>
        </div>

    </div>
</template>

<script>

import axios from 'axios';

export default {
    name: 'LandingView',
    data() {
        return {
            name: "karthik"
        }
    }
}
</script>